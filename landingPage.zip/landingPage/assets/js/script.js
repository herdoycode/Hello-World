// Navbar Animation 
const navAnimation = () => {
    const toggler = document.querySelector('.nav__toggler');
    const nav = document.querySelector('.nav__menu');
    const navLink = document.querySelectorAll('.nav__item');
    const toggleIcon = document.querySelector('.bx-menu');

    toggler.addEventListener('click', () => {
        nav.classList.toggle('nav__active');
        toggleIcon.classList.toggle('bx-x');

        // Add Animation
        
        navLink.forEach((link , index) => {
            if(link.style.animation){
                link.style.animation = '';
            }else{
                link.style.animation = `navFade 0.5s ease-in Forwards ${index / 7 + 0.5}s`
            }
        })
    });
};
navAnimation();